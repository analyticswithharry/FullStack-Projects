// Import the built-in 'http' module to create an HTTP server for handling requests and responses
const http = require('http');

// Import the built-in 'fs' module to read HTML files from the file system
const fs = require('fs');

// Import the built-in 'path' module to construct file paths in a cross-platform compatible way
const path = require('path');

// Create an HTTP server and define a request handler function that processes incoming requests
const server = http.createServer((req, res) => {
  // Extract the URL path from the incoming request (e.g., '/', '/home', '/about')
  const url = req.url;

  // Define the file path for landing.html, using path.join to combine the current directory (__dirname) with the filename
  const landingPath = path.join(__dirname, 'landing.html');

  // Define the file path for home.html, ensuring correct path formatting
  const homePath = path.join(__dirname, 'home.html');

  // Define the file path for about.html, relative to the script's directory
  const aboutPath = path.join(__dirname, 'about.html');

  // Define the file path for contact.html, using path.join for reliability
  const contactPath = path.join(__dirname, 'contact.html');

  // Check if the requested URL is the root path ('/'), which corresponds to the landing page
  if (url === '/') {
    // Read the landing.html file asynchronously from the file system
    fs.readFile(landingPath, (err, data) => {
      // Check if an error occurred while reading the file (e.g., file missing or inaccessible)
      if (err) {
        // Set the HTTP status code to 500 (Internal Server Error) for file read failures
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        // Send a plain text error message to the client
        res.write('Internal Server Error');
        // End the response and return to prevent further execution of the callback
        return res.end();
      }
      // Set the HTTP status code to 200 (OK) to indicate a successful response
      res.writeHead(200, { 'Content-Type': 'text/html' });
      // Send the contents of landing.html (stored in 'data' as a Buffer) to the client
      res.write(data);
      // End the response to signal that all data has been sent
      res.end();
    });
  // Check if the requested URL is '/home', corresponding to the home page
  } else if (url === '/home') {
    // Read the home.html file asynchronously
    fs.readFile(homePath, (err, data) => {
      // Check for errors during file reading
      if (err) {
        // Set HTTP status code to 500 for server errors
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        // Send an error message to the client
        res.write('Internal Server Error');
        // End the response and return to stop further execution
        return res.end();
      }
      // Set HTTP status code to 200 and specify that the response contains HTML
      res.writeHead(200, { 'Content-Type': 'text/html' });
      // Send the contents of home.html to the client
      res.write(data);
      // End the response to complete the request
      res.end();
    });
  // Check if the requested URL is '/about', corresponding to the about page
  } else if (url === '/about') {
    // Read the about.html file asynchronously
    fs.readFile(aboutPath, (err, data) => {
      // Check for file reading errors
      if (err) {
        // Set HTTP status code to 500 for server errors
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        // Send an error message to the client
        res.write('Internal Server Error');
        // End the response and return to stop further execution
        return res.end();
      }
      // Set HTTP status code to 200 and indicate HTML content
      res.writeHead(200, { 'Content-Type': 'text/html' });
      // Send the contents of about.html to the client
      res.write(data);
      // End the response to finalize the request
      res.end();
    });
  // Check if the requested URL is '/contact', corresponding to the contact page
  } else if (url === '/contact') {
    // Read the contact.html file asynchronously
    fs.readFile(contactPath, (err, data) => {
      // Check for errors while reading the file
      if (err) {
        // Set HTTP status code to 500 for server errors
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        // Send an error message to the client
        res.write('Internal Server Error');
        // End the response and return to stop further execution
        return res.end();
      }
      // Set HTTP status code to 200 and specify HTML content type
      res.writeHead(200, { 'Content-Type': 'text/html' });
      // Send the contents of contact.html to the client
      res.write(data);
      // End the response to complete the request
      res.end();
    });
  // Handle any URLs that don’t match the defined routes (e.g., '/random')
  } else {
    // Set the HTTP status code to 404 (Not Found) for unrecognized URLs
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    // Send a plain text message indicating the page was not found
    res.write('404 Not Found');
    // End the response to complete the request
    res.end();
  }
});

// Start the server and make it listen for incoming connections on port 8080
server.listen(8080, () => {
  // Log a confirmation message to the console when the server starts successfully
  console.log('Server running at http://localhost:8080');
});