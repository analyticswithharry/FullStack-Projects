// Wait for the page to fully load before running JavaScript
document.addEventListener('DOMContentLoaded', () => {

  // Get references to the button and heading by their IDs
  const btn = document.getElementById('clickBtn');
  const heading = document.getElementById('main-heading');
  const userName = document.getElementById('userInput');
  // Add a click event listener to the button
  btn.addEventListener('click', () => {
    // Change the text of the heading when button is clicked
    heading.textContent = `Hello ${userName.value} Thanks for clicking!`;

    // Change the color of the heading
    heading.style.color = '#00695c';
  });
});
