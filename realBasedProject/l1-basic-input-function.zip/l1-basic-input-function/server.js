// Bring in Path to help locate our files.
const path = require('path');
// Call Express to create our web server.
const express = require('express');
// Build our Express app, the heart of the server.
const app = express();

// Share files like index.html, styles.css, and script.js from the 'public' folder.
app.use(express.static(path.join(__dirname, 'public')));

// When someone visits the main page ('/'), show them index.html.
app.get('/', (req, res) => {
  // Deliver index.html to the visitor.
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Launch the server on port 3000 and let everyone know it's ready.
app.listen(3000, () => {
  console.log('Server is running on http://localhost:3000');
});