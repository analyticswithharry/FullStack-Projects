My Node.js Lessons
A professional Node.js learning project with five lessons to master Express, EJS, and MVC architecture.
Setup

Clone the repository.
Run npm install to install dependencies.
Create a .env file with PORT=3000.
Start the server: node src/app.js.
Visit http://localhost:3000.

Lessons

Basic Server: Display a static page.
User Interaction: Input and update a greeting.
Dynamic Content: Show random tasks.
Form Submission: Submit tasks to the server.
CRUD Operations: Add and delete tasks.

Structure

src/: Core application code.
public/: Static assets (CSS, JS).
views/: EJS templates and partials.
data/: Task dataset.

