// Wait for the page to load, like setting up the stage.
document.addEventListener('DOMContentLoaded', () => {
  // Log a message to confirm the script is ready.
  console.log('Lesson 1: Serving a static page with Node.js!');
});