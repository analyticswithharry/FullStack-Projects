// Wait for the page to load, like setting up the stage.
document.addEventListener('DOMContentLoaded', () => {
  // Gather our actors: the button and task display.
  const btn = document.getElementById('taskBtn');
  const taskDisplay = document.getElementById('task');

  // When the button is clicked, fetch a new random task.
  btn.addEventListener('click', async () => {
    const response = await fetch('/lesson3');
    const html = await response.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    taskDisplay.textContent = doc.querySelector('#task').textContent;
  });
});