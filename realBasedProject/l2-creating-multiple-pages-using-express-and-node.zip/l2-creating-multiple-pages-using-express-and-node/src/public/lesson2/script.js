// Wait for the page to load, like preparing the scene.
document.addEventListener('DOMContentLoaded', () => {
  // Gather our actors: the button, greeting, and input field.
  const btn = document.getElementById('greetBtn');
  const greeting = document.getElementById('greeting');
  const userInput = document.getElementById('userInput');

  // When the button is clicked, create a personalized greeting.
  btn.addEventListener('click', () => {
    const name = userInput.value || 'Guest';
    greeting.textContent = `Hello, ${name}!`;
    greeting.style.color = '#b0003a';
  });
});