// Wait for the page to load, like preparing the scene.
document.addEventListener('DOMContentLoaded', () => {
  // Log a message to confirm the script is ready.
  console.log('Lesson 5: CRUD operations with Node.js!');
});