// Bring in Winston to log our app's activities.
const winston = require('winston');

// Create a logger to track info and errors in a file and console.
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/app.log' }),
    new winston.transports.Console()
  ]
});

// Export the logger to use across the app.
module.exports = logger;