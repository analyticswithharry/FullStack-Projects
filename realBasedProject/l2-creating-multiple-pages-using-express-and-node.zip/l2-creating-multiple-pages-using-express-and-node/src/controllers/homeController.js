// Bring in the logger to track requests.
const logger = require('../config/logger');

// Handle the homepage request.
exports.getHome = (req, res) => {
  logger.info('Accessed homepage');
  res.render('index', { title: 'Node.js Lessons' });
};