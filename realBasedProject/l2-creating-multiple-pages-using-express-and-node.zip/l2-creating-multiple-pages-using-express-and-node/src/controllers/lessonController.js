// Bring in the logger and task data.
const logger = require('../config/logger');
const taskData = require('../data/tasks');

// Handle Lesson 1: Display a static page.
exports.getLesson1 = (req, res) => {
  logger.info('Accessed Lesson 1');
  res.render('lesson1', { title: 'Lesson 1: Basic Server' });
};

// Handle Lesson 2: User interaction page.
exports.getLesson2 = (req, res) => {
  logger.info('Accessed Lesson 2');
  res.render('lesson2', { title: 'Lesson 2: User Interaction' });
};

// Handle Lesson 3: Show a random task.
exports.getLesson3 = (req, res) => {
  logger.info('Accessed Lesson 3');
  const task = taskData.getRandomTask();
  res.render('lesson3', { title: 'Lesson 3: Dynamic Content', task });
};

// Handle Lesson 4: Form submission.
exports.getLesson4 = (req, res) => {
  logger.info('Accessed Lesson 4');
  res.render('lesson4', { title: 'Lesson 4: Form Submission', message: null });
};
exports.postLesson4 = (req, res) => {
  const { task } = req.body;
  logger.info(`Submitted task: ${task}`);
  taskData.addTask(task);
  res.render('lesson4', { title: 'Lesson 4: Form Submission', message: `Added: ${task}` });
};

// Handle Lesson 5: CRUD operations.
exports.getLesson5 = (req, res) => {
  logger.info('Accessed Lesson 5');
  res.render('lesson5', { title: 'Lesson 5: CRUD Operations', tasks: taskData.getTasks() });
};
exports.postLesson5 = (req, res) => {
  const { task } = req.body;
  logger.info(`Added task: ${task}`);
  taskData.addTask(task);
  res.redirect('/lesson5');
};
exports.deleteLesson5 = (req, res) => {
  const { id } = req.body;
  logger.info(`Deleted task ID: ${id}`);
  taskData.deleteTask(parseInt(id));
  res.redirect('/lesson5');
};