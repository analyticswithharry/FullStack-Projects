// Bring in Express to define routes.
const express = require('express');
// Create a router to handle our routes.
const router = express.Router();
// Bring in controllers for handling requests.
const homeController = require('../controllers/homeController');
const lessonController = require('../controllers/lessonController');

// Define routes for the homepage and lessons.
router.get('/', homeController.getHome);
router.get('/lesson1', lessonController.getLesson1);
router.get('/lesson2', lessonController.getLesson2);
router.get('/lesson3', lessonController.getLesson3);
router.get('/lesson4', lessonController.getLesson4);
router.post('/lesson4', lessonController.postLesson4);
router.get('/lesson5', lessonController.getLesson5);
router.post('/lesson5', lessonController.postLesson5);
router.post('/lesson5/delete', lessonController.deleteLesson5);

// Export the router to use in the app.
module.exports = router;