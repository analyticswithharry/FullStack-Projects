// A simple in-memory task dataset for lessons.
let tasks = [
  { id: 1, description: 'Learn Node.js basics' },
  { id: 2, description: 'Build an Express server' },
  { id: 3, description: 'Use EJS templates' }
];

// Export functions to manage tasks.
module.exports = {
  getTasks: () => tasks,
  getRandomTask: () => tasks[Math.floor(Math.random() * tasks.length)],
  addTask: (description) => {
    const newTask = { id: tasks.length + 1, description };
    tasks.push(newTask);
    return newTask;
  },
  deleteTask: (id) => {
    tasks = tasks.filter(task => task.id !== id);
  }
};