// Load environment variables from .env file.
require('dotenv').config();
// Bring in Express to build the server.
const express = require('express');
// Bring in Path for file navigation.
const path = require('path');
// Bring in the logger for tracking activity.
const logger = require('./config/logger');
// Bring in routes for handling requests.
const routes = require('./routes/index');

// Create the Express app, our server's core.
const app = express();

// Set EJS as the template engine for dynamic pages.
app.set('view engine', 'ejs');
// Point to the views folder for EJS templates.
app.set('views', path.join(__dirname, 'views'));

// Parse URL-encoded form data for POST requests.
app.use(express.urlencoded({ extended: true }));
// Serve static files (CSS, JS) from the public folder.
app.use(express.static(path.join(__dirname, 'public')));
// Use our defined routes for handling requests.
app.use('/', routes);

// Handle 404 errors with a custom error page.
app.use((req, res) => {
  logger.error(`404: Page not found - ${req.url}`);
  res.status(404).render('error', { title: '404 - Page Not Found', message: 'Oops! The page you requested does not exist.' });
});

// Start the server on the specified port and log its status.
const port = process.env.PORT || 3000;
app.listen(port, () => {
  logger.info(`Server running on http://localhost:${port}`);
});