Dad Jokes Web App
A production-ready Node.js web application featuring EJS and React (JSX) pages to fetch and display random dad jokes from the icanhazdadjoke API. Built with modern ES Modules, custom CSS, and robust error handling.
Features

Page 1 (EJS): Server-rendered page on port 3000 with an initial dad joke, button to fetch new jokes via AJAX.
Page 2 (React): Client-side rendered page on port 3001 with a button to fetch new jokes.
Modern UI: Responsive design with custom CSS (blue for EJS, red for React), smooth animations, and a clean layout.
Production-Ready: Environment variables, error handling, logging, and modular architecture.
Centralized API: All icanhazdadjoke API calls managed in a single route file.

Prerequisites

Node.js v18 or higher (tested with v24.2.0)
npm

Setup

Navigate to the project:cd l3-wep-app-with-ejs-templating-and-es-modules


Install dependencies:npm install


Create a .env file in the root with:EJS_PORT=3000
REACT_PORT=3001
API_USER_AGENT=l3-wep-app-with-ejs-templating-and-es-modules (https://github.com/yourusername/l3-wep-app)


Build the app:npm run build


Start the app:npm start

Or for development with hot-reload:npm run dev



Access

Page 1 (EJS): http://localhost:3000
Page 2 (React): http://localhost:3001/jokes
Click the "Get a Joke" button on each page to display a new dad joke.

Project Structure
l3-wep-app-with-ejs-templating-and-es-modules/
├── src/
│   ├── config/             # Server configuration
│   ├── routes/             # Express routes
│   ├── views/              # EJS templates
│   ├── public/             # Static assets (CSS, JS)
│   ├── components/         # React components
│   ├── utils/              # Utility functions (logging)
│   └── app.mjs             # Main server entry
├── package.json            # Project metadata
├── .gitignore              # Git ignore rules
├── .babelrc                # Babel configuration
├── babel.config.cjs        # Babel config (CommonJS)
├── webpack.config.cjs      # Webpack configuration (CommonJS)
├── .env                    # Environment variables
├── README.md               # Documentation

Troubleshooting

React Page Not Working:
Run npm run build and check for src/components/JokesPage.js and src/public/dist/jokesPage.bundle.js.
Open browser console (F12 > Console) on http://localhost:3001/jokes for errors.
Ensure npm install completed successfully.


404 Errors:
Verify http://localhost:3001/jokes is accessed, not http://localhost:3001/.
Check server logs (error.log, combined.log) for routing issues.


Build Errors:
Check terminal output for npm run build.
Delete node_modules and package-lock.json, then rerun npm install.



License
MIT
