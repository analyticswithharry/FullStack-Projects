import React, { useState } from 'react';

const JokesPage = () => {
  const [joke, setJoke] = useState('Click the button to get a joke!');

  const fetchJoke = async () => {
    try {
      const response = await fetch('/joke');
      if (!response.ok) throw new Error('Network response was not ok');
      const data = await response.json();
      setJoke(data.joke);
    } catch (error) {
      console.error('Fetch joke error:', error);
      setJoke('Failed to fetch joke!');
    }
  };

  return (
    <div>
      <section className="welcome-message">
        <p className="welcome-text">Enjoy a random dad joke from icanhazdadjoke.com!</p>
      </section>
      <button onClick={fetchJoke} className="action-button">Get a Joke</button>
      <div id="message" className="message-output">{joke}</div>
    </div>
  );
};

export default JokesPage;