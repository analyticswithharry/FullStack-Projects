import React from 'react';
import { createRoot } from 'react-dom/client';
import JokesPage from '../../components/JokesPage.jsx';

try {
  const container = document.getElementById('root');
  if (!container) {
    console.error('Root element not found');
    throw new Error('Root element not found');
  }
  console.log('Rendering React component');
  const root = createRoot(container);
  root.render(<JokesPage />);
} catch (error) {
  console.error('Error rendering React component:', error);
}