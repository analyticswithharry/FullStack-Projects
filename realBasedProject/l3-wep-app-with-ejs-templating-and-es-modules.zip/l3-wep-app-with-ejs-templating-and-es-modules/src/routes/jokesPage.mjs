import express from 'express';
import { reactPort } from '../config/serverConfig.mjs';
import { fetchDadJoke } from './index.mjs';

const router = express.Router();

router.get('/', (req, res) => {
  res.redirect('/jokes');
});

router.get('/jokes', (req, res) => {
  res.render('jokesPage', {
    title: 'Dad Jokes | React',
    serverMessage: `Server running at http://localhost:${reactPort}`
  });
});

router.get('/joke', async (req, res) => {
  const joke = await fetchDadJoke();
  res.json({ joke });
});

export default router;