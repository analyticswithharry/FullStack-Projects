import express from 'express';
import fetch from 'node-fetch';
import { ejsPort } from '../config/serverConfig.mjs';
import { logger } from '../utils/logger.mjs';

const router = express.Router();

// Centralized API logic for icanhazdadjoke
export async function fetchDadJoke() {
  try {
    const response = await fetch('https://icanhazdadjoke.com/', {
      headers: {
        'Accept': 'application/json',
        'User-Agent': process.env.API_USER_AGENT || 'l3-wep-app'
      }
    });
    if (!response.ok) throw new Error(`API error: ${response.status}`);
    const data = await response.json();
    return data.joke;
  } catch (error) {
    logger.error(`Fetch joke error: ${error.message}`);
    return 'Failed to fetch joke. Try again!';
  }
}

router.get('/', async (req, res) => {
  const initialJoke = await fetchDadJoke();
  res.render('index', {
    title: 'Dad Jokes | EJS',
    serverMessage: `Server running at http://localhost:${ejsPort}`,
    initialJoke
  });
});

router.get('/joke', async (req, res) => {
  const joke = await fetchDadJoke();
  res.json({ joke });
});

export default router;