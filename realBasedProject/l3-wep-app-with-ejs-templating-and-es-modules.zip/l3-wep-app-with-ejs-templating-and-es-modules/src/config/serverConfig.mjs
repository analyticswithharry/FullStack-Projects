export const ejsPort = process.env.EJS_PORT || 3000;
export const reactPort = process.env.REACT_PORT || 3001;