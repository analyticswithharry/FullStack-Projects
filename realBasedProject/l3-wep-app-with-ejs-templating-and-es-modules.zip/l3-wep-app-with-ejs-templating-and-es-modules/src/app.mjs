import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import indexRoutes from './routes/index.mjs';
import jokesPageRoutes from './routes/jokesPage.mjs';
import { ejsPort, reactPort } from './config/serverConfig.mjs';
import { logger } from './utils/logger.mjs';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// EJS Server (Port 3000)
const ejsApp = express();
ejsApp.set('view engine', 'ejs');
ejsApp.set('views', path.join(__dirname, 'views'));
ejsApp.use(express.static(path.join(__dirname, 'public')));
ejsApp.use(express.json());
ejsApp.use('/', indexRoutes);

// EJS Error handling
ejsApp.use((req, res) => {
  logger.warn(`404 Not Found: ${req.url}`);
  res.status(404).render('error', { title: 'Not Found', message: 'Page not found' });
});

ejsApp.use((err, req, res, next) => {
  logger.error(`EJS Server Error: ${err.message}`);
  res.status(500).render('error', { title: 'Server Error', message: 'Something went wrong' });
});

// React Server (Port 3001)
const reactApp = express();
reactApp.set('view engine', 'ejs');
reactApp.set('views', path.join(__dirname, 'views'));
reactApp.use(express.static(path.join(__dirname, 'public')));
reactApp.use(express.json());
reactApp.use('/', jokesPageRoutes);

// React Error handling
reactApp.use((req, res) => {
  logger.warn(`404 Not Found: ${req.url}`);
  res.status(404).render('error', { title: 'Not Found', message: 'Page not found' });
});

reactApp.use((err, req, res, next) => {
  logger.error(`React Server Error: ${err.message}`);
  res.status(500).render('error', { title: 'Server Error', message: 'Something went wrong' });
});

// Start servers
ejsApp.listen(ejsPort, () => {
  logger.info(`EJS Server running at http://localhost:${ejsPort}`);
});

reactApp.listen(reactPort, () => {
  logger.info(`React Server running at http://localhost:${reactPort}`);
});