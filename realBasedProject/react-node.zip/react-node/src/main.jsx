// main.jsx: Entry point for the React application
import React from 'react';
import ReactDOM from 'react-dom/client'; // Import ReactDOM for rendering
import App from './App'; // Import the main App component
import './index.css'; // Import global styles

// Render the App component into the root DOM element
ReactDOM.createRoot(document.getElementById('root')).render(
  // Wrap App in StrictMode for development checks
  <React.StrictMode>
    <App />
  </React.StrictMode>
);