// Landing.jsx: Component for the landing page, serving as the entry point
import React from 'react';
import NavBar from './NavBar'; // Import the navigation bar component

// Functional component for the landing page
function Landing() {
  return (
    // Main container with 'landing' class for styling
    <div className="page landing">
      {/* Main heading for the landing page */}
      <h1>Welcome to Our Website</h1>
      {/* Introductory paragraph */}
      <p>Explore our site using the links below!</p>
      {/* Navigation bar for page links */}
      <NavBar />
    </div>
  );
}

// Export the component for use in routing
export default Landing;