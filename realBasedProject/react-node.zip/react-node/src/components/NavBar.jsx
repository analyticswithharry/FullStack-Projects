// NavBar.jsx: Component for the navigation bar, providing links to all pages
import React from 'react';
import { Link } from 'react-router-dom'; // Import Link for client-side navigation

// Functional component for the navigation bar
function NavBar() {
  return (
    // Navigation element with 'nav' class for styling
    <nav className="nav">
      {/* Link to the landing page */}
      <Link to="/">Landing</Link>
      {/* Link to the home page */}
      <Link to="/home">Home</Link>
      {/* Link to the about page */}
      <Link to="/about">About</Link>
      {/* Link to the contact page */}
      <Link to="/contact">Contact</Link>
    </nav>
  );
}

// Export the component for use in page components
export default NavBar;