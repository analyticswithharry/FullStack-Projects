// Contact.jsx: Component for the contact page, providing contact information
import React from 'react';
import NavBar from './NavBar'; // Import the navigation bar component

// Functional component for the contact page
function Contact() {
  return (
    // Main container with 'contact' class for styling
    <div className="page contact">
      {/* Main heading for the contact page */}
      <h1>Contact Us</h1>
      {/* Descriptive paragraph */}
      <p>Get in touch with us via email or phone.</p>
      {/* Navigation bar for page links */}
      <NavBar />
    </div>
  );
}

// Export the component for use in routing
export default Contact;