// About.jsx: Component for the about page, providing site information
import React from 'react';
import NavBar from './NavBar'; // Import the navigation bar component

// Functional component for the about page
function About() {
  return (
    // Main container with 'about' class for styling
    <div className="page about">
      {/* Main heading for the about page */}
      <h1>About Us</h1>
      {/* Descriptive paragraph */}
      <p>Learn more about our mission and team.</p>
      {/* Navigation bar for page links */}
      <NavBar />
    </div>
  );
}

// Export the component for use in routing
export default About;