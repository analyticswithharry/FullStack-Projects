// Home.jsx: Component for the home page, displaying main content
import React from 'react';
import NavBar from './NavBar'; // Import the navigation bar component

// Functional component for the home page
function Home() {
  return (
    // Main container with 'home' class for styling
    <div className="page home">
      {/* Main heading for the home page */}
      <h1>Home Page</h1>
      {/* Descriptive paragraph */}
      <p>Welcome to the home page of our website.</p>
      {/* Navigation bar for page links */}
      <NavBar />
    </div>
  );
}

// Export the component for use in routing
export default Home;