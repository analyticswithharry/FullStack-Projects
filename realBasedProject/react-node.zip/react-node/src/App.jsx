// App.jsx: Main application component, handling routing for the four pages
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // Import routing components
import Landing from './components/Landing'; // Import landing page component
import Home from './components/Home'; // Import home page component
import About from './components/About'; // Import about page component
import Contact from './components/Contact'; // Import contact page component
import './App.css'; // Import styles for the app

// Main App component
function App() {
  return (
    // Wrap the app in Router for client-side routing
    <Router>
      {/* Define routes for the application */}
      <Routes>
        {/* Route for the landing page at root path ('/') */}
        <Route path="/" element={<Landing />} />
        {/* Route for the home page at '/home' */}
        <Route path="/home" element={<Home />} />
        {/* Route for the about page at '/about' */}
        <Route path="/about" element={<About />} />
        {/* Route for the contact page at '/contact' */}
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </Router>
  );
}

// Export the App component as the main entry point
export default App;