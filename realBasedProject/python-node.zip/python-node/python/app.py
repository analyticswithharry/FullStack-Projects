from flask import Flask, send_file, jsonify
import os

app = Flask(__name__, static_folder="../public", static_url_path="/")

@app.route('/')
def landing():
  return send_file(os.path.join(app.static_folder, 'landing.html'))

@app.route('/home')
def home():
  return send_file(os.path.join(app.static_folder, 'home.html'))

@app.route('/about')
def about():
  return send_file(os.path.join(app.static_folder, 'about.html'))

@app.route('/contact')
def contact():
  return send_file(os.path.join(app.static_folder, 'contact.html'))

@app.route('/api/message')
def get_message():
  return jsonify({'message': 'Hello from Python Flask!'})

@app.errorhandler(404)
def not_found(error):
  return '404 Not Found', 404

if __name__ == '__main__':
  app.run(port=5000)